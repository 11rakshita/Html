<?php
$servername = "localhost";
$username = "root";
$password = ""; // Update if different
$dbname = "user_auth"; // Ensure this matches your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
