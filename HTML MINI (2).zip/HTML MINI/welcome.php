<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<?php
// You can include any server-side logic or dynamic content here
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome - Loan EMI & CIBIL Score Management</title>
    <style>
        /* General styles */
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-image: url('welcome.jpg'); /* Replace with your image URL */
            margin: 0;
            padding: 0;
        }

        /* Title animation */
        h2 {
            font-size: 3em;
            font-weight: bold;
            background: linear-gradient(to left, #50c6ea, #0797ea, #0151a0,rgb(17, 4, 132),rgb(10, 2, 61));
            background-size: 400% 400%;
            background-clip: text;
            color: transparent;
            animation: gradientAnimation 4s ease infinite;
        }

        /* Keyframes for the gradient text animation */
        @keyframes gradientAnimation {
            0% {
                background-position: 400% 0%;
            }
            50% {
                background-position: 0% 100%;
            }
            100% {
                background-position: 400% 0%;
            }
        }

        /* Image hover animation */
        img {
            width: 800px;
            transition: transform 0.5s ease-in-out;
        }

        img:hover {
            transform: scale(1.1);  /* Slight zoom-in effect */
        }

        /* Navigation links */
        ul {
            list-style-type: none;
            padding: 0;
        }

        li {
            margin: 10px 0;
        }

        a {
            text-decoration: none;
            color:rgb(3, 7, 14);
            font-size: 1.2em;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h2>Welcome to Loan & CIBIL Score Management</h2>
    <p>
        <a href="viewcalcu.php">View Calculation</a> | 
        <a href="List.php">View the plan</a> 
    </p>

    <!-- Image with hover animation -->
    <img src="image.webp" usemap="#loanmap" alt="Loan Info" width="800">
    <map name="loanmap">
        <area shape="rect" coords="0,0,200,200" href="viewcalcu.php" target="main" alt="Details">
    </map>
</body>
</html>
