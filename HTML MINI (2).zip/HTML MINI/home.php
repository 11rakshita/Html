<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page - Loan & CIBIL Score Management</title>
    <style>
        /* General Reset */
        body, html {
            margin: 0;
            padding: 0;
            height: 100%; /* Full height */
            background-image: url('login.png'); /* Replace with your image URL */
            display: flex;
            flex-direction: column;
        }

        /* Main Content Section */
        .content {
            display: flex;
            flex-direction: column;
            align-items: center; /* Horizontally center the content */
            justify-content: flex-start; /* Start from the top but allow space for footer */
            padding: 20px;
            flex-grow: 0; /* This allows content to take up remaining space */
        }

        h2 {
            color: #0e21d1;
        }

        .section {
            margin-bottom: 30px;
            background-color: rgba(0, 0, 0, 0.1); /* Light gray background for sections */
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 80%; /* Limit section width to 80% of the page */
            max-width: 800px; /* Prevent it from getting too wide */
        }

        .section h3 {
            color: #3e14e7;
            text-align: center;
        }

        .section p {
            font-size: 1.1em;
            line-height: 1.6;
            text-align: center;
        }

        .section ul {
            list-style: none;
            padding: 0;
            text-align: center;
        }

        .section ul li {
            margin-bottom: 10px;
        }

        /* Footer Styling */
        .footer {
            background: linear-gradient(to right, #d9d8d7, #798ced);
            color: rgb(87, 81, 254);
            text-align: center;
            padding: 20px;
            width: 100%;
            font-size: 1em;
            margin-top: auto; /* Push the footer to the bottom */
        }

        .footer a {
            color: #0f718f;
            text-decoration: none;
            margin: 0 10px;
        }

        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <!-- Main Content -->
    <div class="content">
        <!-- Services Section -->
        <div class="section">
            <h3>Our Services</h3>
            <p>We offer a variety of services to help you manage your loans and improve your CIBIL score:</p>
            <ul>
                <li>Loan EMI Calculation</li>
                <li>CIBIL Score Monitoring</li>
                <li>Credit Report Analysis and Advice</li>
                <li>Loan Comparisons and Recommendations</li>
            </ul>
        </div>

        <!-- Contact Details Section -->
        <div class="section">
            <h3>Contact Us</h3>
            <p>If you have any questions or need assistance, feel free to reach out:</p>
            <p><strong>Email:</strong> support@loanmanagement.com</p>
            <p><strong>Phone:</strong> +1-234-567-890</p>
            <p><strong>Address:</strong> 123 Financial Lane, Suite 100, Money City, USA</p>
        </div>

        <!-- FAQ Section -->
        <div class="section">
            <h3>Frequently Asked Questions (FAQ)</h3>
            <p>Here are some common questions answered:</p>
            <ul>
                <li><strong>What is a CIBIL score?</strong> It is a score that reflects your creditworthiness based on your financial history.</li>
                <li><strong>How can I improve my CIBIL score?</strong> By paying off loans and credit card dues on time and maintaining a low credit utilization ratio.</li>
                <li><strong>How can I calculate my loan EMI?</strong> Use our EMI calculator, which takes the loan amount, interest rate, and tenure into account.</li>
            </ul>
        </div>
    </div>

    <!-- Fixed Footer -->
    <footer class="footer">
        <p>&copy; 2024 Loan & CIBIL Score Management. All rights reserved.</p>
        <p>
            <a href="#services">Services</a> | 
            <a href="#contact">Contact</a> | 
            <a href="#faq">FAQ</a>
        </p>
    </footer>
</body>
</html>
