<?php
session_start();
include('db.php'); // Database connection file

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$emiResult = '';
$message = ''; // For success or error messages

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle EMI Calculation and Data Insertion
    if (isset($_POST['calculate-emi'])) {
        $loanAmount = floatval($_POST['loan-amount']);
        $interestRate = floatval($_POST['interest-rate']);
        $loanTenure = intval($_POST['loan-tenure']);

        if ($loanAmount > 0 && $interestRate > 0 && $loanTenure > 0) {
            $monthlyRate = $interestRate / (12 * 100); // Convert annual rate to monthly
            $tenureInMonths = $loanTenure * 12; // Convert years to months
            $emi = ($loanAmount * $monthlyRate * pow(1 + $monthlyRate, $tenureInMonths)) / 
                   (pow(1 + $monthlyRate, $tenureInMonths) - 1);

            $user_id = $_SESSION['user_id']; // Get user ID from session

            // Insert data into database
            $sql = "INSERT INTO loan_details (user_id, loan_amount, interest_rate, loan_tenure, emi) 
                    VALUES ('$user_id', '$loanAmount', '$interestRate', '$loanTenure', '$emi')";

            if ($conn->query($sql) === TRUE) {
                $emiResult = "Your EMI is ₹" . number_format($emi, 2) . ". This information has been saved.";
            } else {
                $emiResult = "Error: " . $conn->error;
            }
        } else {
            $emiResult = "Please provide valid inputs.";
        }
    }

    // Handle Delete Record Request
    if (isset($_POST['delete-record'])) {
        $record_id = intval($_POST['record-id']);
        $sql = "DELETE FROM loan_details WHERE id = '$record_id' AND user_id = '{$_SESSION['user_id']}'";

        if ($conn->query($sql) === TRUE) {
            $message = "Record deleted successfully.";
        } else {
            $message = "Error deleting record: " . $conn->error;
        }
    }
}

// Fetch all records for the logged-in user
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM loan_details WHERE user_id = '$user_id'";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loan EMI & CIBIL Management</title>
    <style>
         <style>
    body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-image: url('login.png');
    color: #333;
}


.nav-links {
    list-style: none;
    padding: 0;
    margin: 0;
    display: flex;
    justify-content: center;
}

.nav-links li {
    margin: 0 10px;
}

.nav-links a {
    color: black;
    text-decoration: none;
    font-weight: bold;
}

.nav-links a:hover {
    text-decoration: underline;
}

.section {
    padding: 20px;
    margin: 20px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.section h2 {
    color: #004d99;
}

.form label, 
.form input, 
.form button {
    display: block;
    margin: 10px 0;
}

input, button {
    padding: 10px;
    width: 100%;
    max-width: 300px;
    margin: auto;
}

button {
    background-color: #004d99;
    color: white;
    border: none;
    cursor: pointer;
}

button:hover {
    background-color: #003366;
}

.result {
    margin-top: 20px;
    padding: 10px;
    background: #eaf5ff;
    border: 1px solid #004d99;
    border-radius: 5px;
}
.thankyou-button {
    padding: 15px 30px;
    background-color: #eaf5ff;
    color:rgb(22, 126, 223);
    text-decoration: none;
    border-radius: 5px;
    font-size: 1.1em;
    margin-top: 20px;
}

.thankyou-button:hover {
    background-color:rgb(127, 184, 240);
}


        /* Your existing styles here */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ccc;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f4f4f9;
        }

        .delete-button {
            color: white;
            background-color: #d9534f;
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .delete-button:hover {
            background-color: #c9302c;
        }
    </style>
</head>
<body>
    <header class="header">
        <center><h1>Loan EMI & CIBIL Score Management</h1></center>
        <nav>
            <ul class="nav-links">
                <li><a href="#emi-calculator">EMI Calculator</a></li>
                <li><a href="#cibil-score">CIBIL Score</a></li>
                <li><a href="#user-management">User Management</a></li>
            </ul>
        </nav>
    </header>
    <main>
    <section id="emi-calculator" class="section">
            <h2>EMI Calculator</h2>
            <form id="emi-form" method="POST">
                <label for="loan-amount">Loan Amount (₹):</label>
                <input type="number" id="loan-amount" name="loan-amount" placeholder="Enter amount" required>

                <label for="interest-rate">Interest Rate (% per annum):</label>
                <input type="number" id="interest-rate" name="interest-rate" placeholder="Enter rate" step="0.01" required>

                <label for="loan-tenure">Loan Tenure (years):</label>
                <input type="number" id="loan-tenure" name="loan-tenure" placeholder="Enter years" required>

                <button type="submit" name="calculate-emi">Calculate EMI</button>
            </form>
            <div id="emi-result" class="result">
                <?php echo $emiResult; ?>
            </div>
        </section>

        <section id="cibil-score" class="section">
            <h2>CIBIL Score</h2>
            <p>Track your credit score to maintain financial health. Ensure your score stays above 750 for the best loan offers.</p>
            <button onclick="showCIBIL()">Check CIBIL Score</button>
            <div id="cibil-result" class="result">
                <?php
                if (isset($_GET['show-cibil'])) {
                    echo "Your CIBIL Score is 785 (Excellent)";
                }
                ?>
            </div>
        </section>

        <section id="user-management" class="section">
            <h2>User Management</h2>
            <p>Manage user data and loan details securely.</p>
            <button onclick="showUserManagement()">Manage Users</button>
            <div id="user-result" class="result">
                <?php
                if (isset($_GET['manage-users'])) {
                    echo "User management functionality coming soon!";
                }
                ?>
            </div>
        </section>

        <section id="loan-records" class="section">
            <h2>Saved Loan Records</h2>
            <?php if ($message): ?>
                <p><?php echo $message; ?></p>
            <?php endif; ?>

            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Loan Amount (₹)</th>
                        <th>Interest Rate (%)</th>
                        <th>Loan Tenure (Years)</th>
                        <th>EMI (₹)</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td><?php echo number_format($row['loan_amount'], 2); ?></td>
                                <td><?php echo $row['interest_rate']; ?></td>
                                <td><?php echo $row['loan_tenure']; ?></td>
                                <td><?php echo number_format($row['emi'], 2); ?></td>
                                <td>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="record-id" value="<?php echo $row['id']; ?>">
                                        <button type="submit" name="delete-record" class="delete-button">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6">No records found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </section>
    </main>
    <script>
        function showCIBIL() {
            window.location.href = "?show-cibil=true";
        }

        function showUserManagement() {
            window.location.href = "?manage-users=true";
        }
    </script>
     <div class="thankyou-button"><center>
     <a href="thankyou.php" class="back-button">ThankYou</a>
     <center>
    </div>
</body>
</html>
