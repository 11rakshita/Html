<?php
session_start();

// Check if user is logged in, if not, redirect to the login page.
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You</title>
    <style>
        /* General Reset */
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            background-image: url('home.jpg');
            font-family: 'Arial', sans-serif;
        }

        /* Background Styling */
        .thank-you-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
            text-align: center;
            color: #090808;
        }

        /* Message Styling */
        .thank-you-message {
            background: rgba(179, 171, 171, 0.6);
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        .thank-you-message h1 {
            font-size: 3em;
            margin-bottom: 20px;
            animation: fadeIn 1.5s ease-in-out;
        }

        .thank-you-message p {
            font-size: 1.2em;
            margin-bottom: 30px;
            animation: fadeIn 2s ease-in-out;
        }

        /* Button Styling */
        .back-button {
            display: inline-block;
            padding: 15px 30px;
            font-size: 1em;
            text-decoration: none;
            color: #7eacec;
            background: #ffffff;
            border-radius: 5px;
            font-weight: bold;
            transition: 0.3s ease;
            animation: fadeIn 2.5s ease-in-out;
        }

        .back-button:hover {
            background: #4db5ea;
            color: #ffffff;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        /* Fade-In Animation */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <div class="thank-you-container">
        <div class="thank-you-message">
            <h1>Thank You!</h1>
            <p>Your submission has been received successfully.</p>
            <a href="index.php" class="back-button">Go Back to Homepage</a>
        </div>
    </div>
</body>
</html>
