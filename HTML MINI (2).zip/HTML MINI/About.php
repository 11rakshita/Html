<?php
    // about.php
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About - Loan & CIBIL Score Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('login.png'); /* Replace with your image URL */
            background-size: cover; /* Ensure the image covers the entire background */
            background-position: center center; /* Center the background image */
            background-attachment: fixed; 
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #0e0d0d;
        }

        .about-container {
            background-color: rgba(255, 255, 255, 0.404);
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 80%;
            max-width: 1000px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .about-content {
            margin-bottom: 20px;
        }

        .about-content p {
            font-size: 1.1em;
            line-height: 1.6;
            margin-bottom: 20px;
        }

        .about-content h3 {
            color: #073566;
            margin-bottom: 10px;
        }

        .back-link {
            text-align: center;
            margin-top: 20px;
        }

        .back-link a {
            color: #062b53;
            text-decoration: none;
            font-size: 16px;
        }

        .back-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="about-container">
        <h2>About Loan & CIBIL Score Management</h2>
        
        <div class="about-content">
            <h3>Our Mission</h3>
            <p>We aim to empower individuals with the tools and knowledge to manage their loan repayments and improve their CIBIL scores effectively. Our platform provides users with reliable loan EMI calculators, CIBIL score tracking, and expert advice to help improve their creditworthiness.</p>
        </div>

        <div class="about-content">
            <h3>Our Services</h3>
            <p>We offer the following services to help you manage your financial health:</p>
            <ul>
                <li>Loan EMI Calculation: Accurately calculate your monthly loan EMI based on the loan amount, interest rate, and tenure.</li>
                <li>CIBIL Score Monitoring: Track your CIBIL score and receive alerts for changes in your credit status.</li>
                <li>Credit Report Analysis: Get insights on how your credit report affects your loan eligibility and how to improve it.</li>
                <li>Loan Comparisons: Compare loan offers from multiple lenders to find the best loan deal that suits your needs.</li>
            </ul>
        </div>

        <div class="about-content">
            <h3>Why Choose Us?</h3>
            <p>Our platform is designed to be user-friendly and informative, ensuring you have all the resources you need to make informed financial decisions. We believe that financial literacy is key to managing loans and improving CIBIL scores. By using our tools and services, you can ensure a better financial future.</p>
        </div>

        <!-- Back to Home Link -->
        <div class="back-link">
            <p><a href="index.php">Back to Home</a></p>
        </div>
    </div>

</body>
</html>
