<?php
// Sample data for loan types and their respective amounts decided by the bank
$loan_types = [
   
        ['type' => 'Home Loan', 'amount' => '₹1,500,000'],
        ['type' => 'Personal Loan', 'amount' => '₹500,000'],
        ['type' => 'Car Loan', 'amount' => '₹1,000,000'],
        ['type' => 'Education Loan', 'amount' => '₹800,000'],
        ['type' => 'Business Loan', 'amount' => '₹5,000,000'],
        ['type' => 'Gold Loan', 'amount' => '₹300,000'],
        ['type' => 'Mortgage Loan', 'amount' => '₹2,000,000'],
        ['type' => 'Agriculture Loan', 'amount' => '₹1,200,000'],
        ['type' => 'Medical Loan', 'amount' => '₹200,000'],
        ['type' => 'Wedding Loan', 'amount' => '₹500,000'],
        ['type' => 'Consumer Durable Loan', 'amount' => '₹150,000'],
        ['type' => 'Vacation Loan', 'amount' => '₹350,000'],
        ['type' => 'Loan Against Property', 'amount' => '₹3,000,000'],
        ['type' => 'Startup Loan', 'amount' => '₹2,500,000'],
        ['type' => 'Debt Consolidation Loan', 'amount' => '₹1,000,000']

    
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loan Types and Amounts</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fa;
            color: #333;
            background-image: url('login.png'); /* Replace with your image URL */
            background-size: cover; /* Ensure the image covers the entire background */
            background-position: center center; /* Center the background image */
            background-attachment: fixed; 
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            color: #004d99;
            margin-top: 20px;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        table th, table td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        table th {
            background-color: #004d99;
            color: white;
        }

        table td {
            color: #555;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tr:hover {
            background-color: #f1f1f1;
        }

        .loan-table-container {
            text-align: center;
        }

        .loan-table-container p {
            font-size: 1.2em;
            color: #444;
        }

        /* Button to go back to the welcome page */
        .back-button {
            display: block;
            width: 200px;
            margin: 20px auto;
            padding: 10px;
            background-color: #004d99;
            color: white;
            text-align: center;
            text-decoration: none;
            font-weight: bold;
            border-radius: 5px;
        }

        .back-button:hover {
            background-color: #003366;
        }
    </style>
</head>
<body>

    <h2>Loan Types and Amounts Decided by Bank</h2>

    <div class="loan-table-container">
        <p>Here is the list of loan types and their respective amounts decided by the bank:</p>

        <table>
            <thead>
                <tr>
                    <th>Loan Type</th>
                    <th>Amount Decided by Bank</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($loan_types as $loan): ?>
                    <tr>
                        <td><?php echo $loan['type']; ?></td>
                        <td><?php echo $loan['amount']; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Back button to Welcome Page -->
        <a href="welcome.php" class="back-button">Back to Welcome Page</a>
    </div>

</body>
</html>
