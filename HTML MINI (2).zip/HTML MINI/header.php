<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loan & CIBIL Score Management</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #d9d8d7, #98a6eb);
        }

        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            color: rgb(26, 30, 223);
        }

        /* Logo and Title Styling */
        .logo-title {
            display: flex;
            align-items: center;
        }

        .logo img {
            width: 50px;
            height: 50px;
            margin-right: 15px;
        }

        .logo-title h1 {
            margin: 0;
            font-size: 1.8em;
        }

        /* Menu Styling */
        .menu {
            display: flex;
            gap: 20px;
        }

        .menu a {
            text-decoration: none;
            color: rgb(31, 31, 220);
            font-size: 1.2em;
            transition: color 0.3s;
        }

        .menu a:hover {
            color: #FFD700;
        }

        .menu a:active {
            color: #FFD700;
        }
    </style>
</head>
<body>
    <div class="header-container">
        <!-- Left side: Logo and Title -->
        <div class="logo-title">
            <div class="logo">
                <img src="logo.webp" alt="Logo">
            </div>
            <h1>Loan & CIBIL Score Management</h1>
        </div>

        <!-- Right side: Menu options (About and Login) -->
        <div class="menu">
            <a href="About.php" >About</a>
            <a href="Login.php" >Login</a>
        </div>
    </div>
</body>
</html>
