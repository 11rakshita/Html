

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    include 'db.php'; // Include the database connection

    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $dob = $_POST['dob'];
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);

    if ($password !== $confirm_password) {
        echo "<p style='color:red;'>Passwords do not match!</p>";
    } else {
        $hashed_password = password_hash($password, PASSWORD_BCRYPT); // Hash the password

        $sql = "INSERT INTO users (username, email, dob, password) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $stmt->bind_param("ssss", $username, $email, $dob, $hashed_password);
            if ($stmt->execute()) {
                echo "<p style='color:green;'>Registration successful! <a href='login.php'>Login now</a></p>";
            } else {
                echo "<p style='color:red;'>Error: " . $stmt->error . "</p>";
            }
            $stmt->close();
        } else {
            echo "<p style='color:red;'>Error preparing statement: " . $conn->error . "</p>";
        }
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Loan EMI & CIBIL Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f3f4f6;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            background-image: url('signup.jpg'); /* Replace with your image URL */
            background-size: cover; /* Ensure the image covers the entire background */
            background-position: center center; /* Center the background image */
            background-attachment: fixed; 
            align-items: center;
            height: 100vh;
        }

        .signup-container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            text-align: center;
            width: 400px;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
            font-size: 1.8rem;
        }

        .input-field {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
        }

        .btn {
            width: 100%;
            padding: 12px;
            margin-top: 15px;
            background: #4caf50;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 1.2rem;
            cursor: pointer;
        }

        .btn:hover {
            background: #45a049;
        }

        .error {
            color: red;
            font-size: 0.9rem;
        }
        
    </style>
</head>
<body>
    <div class="signup-container">
        <h2>Sign Up</h2>
        <form method="POST">
            <input type="text" name="username" class="input-field" placeholder="Username" required>
            <input type="email" name="email" class="input-field" placeholder="Email" required>
            <input type="date" name="dob" class="input-field" required>
            <input type="password" name="password" class="input-field" placeholder="Password" required>
            <input type="password" name="confirm_password" class="input-field" placeholder="Confirm Password" required>
            <button type="submit" class="btn">Sign Up</button>
        </form>

    </div>
</body>
</html>
